<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST["usuario"];
    $password = $_POST["passwd"];

    // Verifica que el usuario y la contraseña no estén vacíos
    if (empty($user) || empty($password)) {
        echo "Por favor ingresa el usuario y la contraseña.";
        exit();
    }

    $dsn = "mysql:dbname=VelocidadyEstilo;host=127.0.0.1;";
    $usuario = "root";
    $clave = "";

    try {
        $bd = new PDO($dsn, $usuario, $clave);
        $bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "SELECT * FROM Usuarios WHERE usuario = :user AND passw = :password";
        $stmt = $bd->prepare($sql);
        $stmt->bindParam(':user', $user);
        $stmt->bindParam(':password', $password);

        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            // Almacena el nombre de usuario en una cookie válida durante 7 días (ajusta el tiempo según tu preferencia)
            setcookie('nombre_usuario', $result['nombre'], time() + (86400 * 7), "/"); // 86400 = 1 día en segundos

            // Verifica si el usuario es un administrador
            if ($result['role'] == 'admin') {
                // Redirige a la página para agregar producto
                header("Location: /HTML/AñadirProducto.html");
                exit();
            } else {
                // Redirige a la página principal
                echo '<script type="text/javascript">
                    alert("Credenciales correctas");
                    window.location.href = "/HTML/paginaPricipal.html"; // Redirige a la página principal
                </script>';
                exit();
            }
        } else {
            echo '<script type="text/javascript">
                alert("Credenciales incorrectas");
                window.location.href = "/HTML/login.html"; // Redirige a la página de inicio de sesión
            </script>';
            exit();
        }

        $bd = null;
    } catch (PDOException $e) {
        echo "Falló la conexión: " . $e->getMessage();
    }
}
?>



