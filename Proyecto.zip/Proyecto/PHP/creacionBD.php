<?php

$dsn = "mysql:host=localhost;";
$usuario = "root";
$clave = "";

try {
    $bd = new PDO($dsn, $usuario, $clave);
    $nombreBD = "VelocidadyEstilo";

    $sql = "CREATE DATABASE IF NOT EXISTS $nombreBD CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    if ($bd->query($sql)) {
        echo "<p>Base de datos $nombreBD creada correctamente</p>";
        $dsn = "mysql:dbname=$nombreBD;host=127.0.0.1;";
        $bd = null;
        $bd = new PDO($dsn, $usuario, $clave);

        // Tabla Usuarios
        $nombreTabla = "Usuarios";
        $crearTabla = "CREATE TABLE IF NOT EXISTS $nombreTabla(
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            nombre VARCHAR(20) NOT NULL,
            apellidos VARCHAR(50) NOT NULL,
            correo VARCHAR(50) NOT NULL UNIQUE,
            usuario VARCHAR(20) NOT NULL UNIQUE,
            passw VARCHAR(40) NOT NULL,
            direccion VARCHAR(100) NOT NULL,
            role ENUM('user', 'admin') DEFAULT 'user'
        )";
        if ($bd->query($crearTabla)) {
            echo "<p>Tabla $nombreTabla creada correctamente</p>";
        }

        // Tabla Productos
        $nombreTabla = "Productos";
        $crearTabla = "CREATE TABLE IF NOT EXISTS $nombreTabla(
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            nombre VARCHAR(50) NOT NULL,
            precio DECIMAL(10,2) NOT NULL,
            imagen VARCHAR(100),
            talla VARCHAR(50),
            escuderia VARCHAR(50),
            cantidad INT UNSIGNED
        )";
        if ($bd->query($crearTabla)) {
            echo "<p>Tabla $nombreTabla creada correctamente</p>";
        }

        // Tabla Cuentas
        $nombreTabla = "Cuentas";
        $crearTabla = "CREATE TABLE IF NOT EXISTS $nombreTabla(
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_usuario INT UNSIGNED,
            id_producto INT UNSIGNED,
            precio DECIMAL(10,2),
            destino VARCHAR(100),
            FOREIGN KEY (id_usuario) REFERENCES Usuarios(id),
            FOREIGN KEY (id_producto) REFERENCES Productos(id)
        )";
        if ($bd->query($crearTabla)) {
            echo "<p>Tabla $nombreTabla creada correctamente</p>";
        }

        // Tabla Administradores
        $nombreTabla = "Administradores";
        $crearTabla = "CREATE TABLE IF NOT EXISTS $nombreTabla(
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            usuario VARCHAR(20) NOT NULL UNIQUE,
            passw VARCHAR(255) NOT NULL
        )";
        if ($bd->query($crearTabla)) {
            echo "<p>Tabla $nombreTabla creada correctamente</p>";
        }

    } else {
        echo "<p>Error al crear la base de datos. </p>";
    }
    $bd = null;
} catch (PDOException $e) {
    echo "Falló la conexión: " . $e->getMessage();
}
?>
