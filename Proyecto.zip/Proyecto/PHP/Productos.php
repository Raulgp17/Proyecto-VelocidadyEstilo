<?php
session_start();
$dsn = "mysql:dbname=VelocidadyEstilo;host=127.0.0.1;";
$usuario = "root";
$clave = "";

try {
    $bd = new PDO($dsn, $usuario, $clave);
    $bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "SELECT * FROM Productos";
    $stmt = $bd->prepare($sql);
    $stmt->execute();
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "Falló la conexión: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../../Imagenes/favicoin.png" type="image/x-icon">
    <link rel="stylesheet" href="../../CSS/Productos.css">
    <title>Lista de Productos</title>
</head>
<body>
<nav>
    <a href="../../HTML/paginaPricipal.html">Inicio</a>
    <a href="../../HTML/Equipos/aston.html">Aston Martin</a>
    <a href="../../HTML/Equipos/Mclaren.html">Mclaren</a>
    <a href="../../PHP/Productos.php">Todos los productos</a>
    <a id="Sesion" href="../../HTML/login.html"> <img src="../Imagenes/login_icon.png" alt="Login"></a>
    <a id="Carrito" href="../../PHP/carrito.php"> <img src="../Imagenes/carrito.png" alt="carrito"></a>
</nav>
<h1>Lista de Productos</h1>
<select id="filtroEscuderia">
    <option value="todos">Todos los equipos</option>
    <option value="Aston Martin">Aston Martin</option>
    <option value="Alpine">Alpine</option>
    <option value="BMW Sauber">BMW Sauber</option>
    <option value="Ferrari">Ferrari</option>
    <option value="Haas">Haas</option>
    <option value="Jaguar">Jaguar</option>
    <option value="Jordan">Jordan</option>
    <option value="Kick Sauber">Kick Sauber</option>
    <option value="Lotus">Lotus</option>
    <option value="Mclaren">Mclaren</option>
    <option value="Mercedes">Mercedes</option>
    <option value="Red Bull">Red Bull</option>
    <option value="Redbull">RB</option>
    <option value="Renault">Renault</option>
    <option value="Toyota">Toyota</option>
    <option value="Williams">Williams</option>
</select>
<br>
<select id="filtroTalla">
    <option value="todas">Todas las tallas</option>
    <option value="S">S</option>
    <option value="M">M</option>
    <option value="L">L</option>
    <option value="XL">XL</option>
</select>
<br>
<br>
<br>
<ul id="listaProductos">
    <?php foreach ($productos as $producto): ?>
        <li class="producto" data-id="<?php echo $producto['id']; ?>" data-nombre="<?php echo $producto['nombre']; ?>" data-precio="<?php echo $producto['precio']; ?>" data-escuderia="<?php echo $producto['escuderia']; ?>" data-talla="<?php echo $producto['talla']; ?>">
            <?php if (!empty($producto['imagen'])): ?>
                <img src="<?php echo $producto['imagen']; ?>" alt="<?php echo $producto['nombre']; ?>" style="max-width: 100px;">
            <?php endif; ?>
            
            <p>Precio: <?php echo $producto['precio']; ?>€</p>
            <p>Talla: <?php echo $producto['talla']; ?></p>
            <p>Escudería: <?php echo $producto['escuderia']; ?></p>
            
            <center><button class="añadirProducto">Añadir al carrito</button></center>
        </li>
        <br>
    <?php endforeach; ?>
</ul>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function(){
        // Filtrar productos por escudería
        $('#filtroEscuderia, #filtroTalla').change(function(){
            filtrarProductos();
        });

        // Función para filtrar productos
        function filtrarProductos() {
            var equipoSeleccionado = $('#filtroEscuderia').val();
            var tallaSeleccionada = $('#filtroTalla').val();

            $('.producto').each(function(){
                var escuderiaProducto = $(this).data('escuderia');
                var tallaProducto = $(this).data('talla');

                if ((equipoSeleccionado === 'todos' || equipoSeleccionado === escuderiaProducto) &&
                    (tallaSeleccionada === 'todas' || tallaSeleccionada === tallaProducto)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        }

        // Añadir producto al carrito
        $('.añadirProducto').click(function(){
            var productoId = $(this).closest('.producto').data('id');
            var nombre = $(this).closest('.producto').data('nombre');
            var precio = $(this).closest('.producto').data('precio');
            var escuderia = $(this).closest('.producto').data('escuderia');
            var talla = $(this).closest('.producto').data('talla');

            $.post('add_to_cart.php', {
                id: productoId,
                nombre: nombre,
                precio: precio,
                escuderia: escuderia,
                talla: talla
            }, function(response) {
                alert(response);
            });
        });
    });
</script>
</body>
</html>
