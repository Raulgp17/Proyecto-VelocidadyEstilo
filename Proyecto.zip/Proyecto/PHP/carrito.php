<?php
session_start();

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "VelocidadyEstilo";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Manejar la eliminación de un solo producto
if (isset($_POST['eliminar'])) {
    $indice = $_POST['indice'];
    unset($_SESSION['carrito'][$indice]);
    $_SESSION['carrito'] = array_values($_SESSION['carrito']); // Reindexar el carrito
}

// Manejar la eliminación de todos los productos
if (isset($_POST['eliminar_todo'])) {
    $_SESSION['carrito'] = [];
}

// Manejar la compra
if (isset($_POST['comprar'])) {
    $usuario_id = 1; // Cambiar esto por el id del usuario autenticado
    $destino = "Dirección de envío"; // Cambiar esto por la dirección real del usuario
    $compraValida = true;

    foreach ($_SESSION['carrito'] as $producto) {
        // Verificar existencias
        $sql = "SELECT cantidad FROM Productos WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $producto['id']);
        $stmt->execute();
        $stmt->bind_result($cantidad);
        $stmt->fetch();
        $stmt->close();

        if ($cantidad < $producto['cantidad']) {
            $compraValida = false;
            echo "<script>alert('No hay suficientes existencias del producto: " . $producto['nombre'] . "');</script>";
            break;
        }
    }

    if ($compraValida) {
        foreach ($_SESSION['carrito'] as $producto) {
            // Insertar en la tabla Cuentas
            $sql = "INSERT INTO Cuentas (id_usuario, id_producto, precio, destino) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iids", $usuario_id, $producto['id'], $producto['precio'], $destino);
            $stmt->execute();
            $stmt->close();

            // Restar la cantidad comprada del producto
            $sql = "UPDATE Productos SET cantidad = cantidad - ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $producto['cantidad'], $producto['id']);
            $stmt->execute();
            $stmt->close();
        }
        
        $_SESSION['carrito'] = []; // Vaciar el carrito después de la compra
        echo "<script>alert('Gracias por comprar en Velocidad y Estilo');</script>";
    }
}

$carrito = isset($_SESSION['carrito']) ? $_SESSION['carrito'] : [];
$total = 0;

foreach ($carrito as $producto) {
    $total += $producto['precio'] * $producto['cantidad'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../../Imagenes/favicoin.png" type="image/x-icon">
    <link rel="stylesheet" href="../../CSS/Carrito.css">
    <title>Carrito de Compras</title>
</head>
<body>
<nav>
    <a href="../../HTML/paginaPricipal.html">Inicio</a>
    <a href="../../HTML/Equipos/aston.html">Aston Martin</a>
    <a href="../../HTML/Equipos/Mclaren.html">Mclaren</a>
    <a href="../../PHP/Productos.php">Todos los productos</a>
    <a id="Sesion" href="../../HTML/login.html"> <img src="../Imagenes/login_icon.png" alt="Login"></a>
    <a id="Carrito" href="../../PHP/carrito.php"> <img src="../Imagenes/carrito.png" alt="carrito"></a>
</nav>

<h1>Carrito de Compras</h1>
<form action="carrito.php" method="post">
    <table>
        <thead>
            <tr>
                <th>Producto</th>
                <th>Escudería</th>
                <th>Talla</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>Total</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($carrito as $indice => $producto): ?>
                <tr>
                    <td><?php echo $producto['nombre']; ?></td>
                    <td><?php echo $producto['escuderia']; ?></td>
                    <td><?php echo $producto['talla']; ?></td>
                    <td><?php echo $producto['precio']; ?>€</td>
                    <td><?php echo $producto['cantidad']; ?></td>
                    <td><?php echo $producto['precio'] * $producto['cantidad']; ?>€</td>
                    <td>
                        <button type="submit" name="eliminar" value="Eliminar">Eliminar</button>
                        <input type="hidden" name="indice" value="<?php echo $indice; ?>">
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <h2>Total: <?php echo $total; ?>€</h2>
    <center><button type="submit" name="eliminar_todo" value="Eliminar Todo">Eliminar Todo</button></center><br>
    <center><button type="submit" name="comprar" value="Comprar">Comprar</button></center>
</form>
<br>
<form >
    <label id="direccion" for="direccion">Dirección:</label>
    <input type="text" id="direccion" name="direccion">

    <label id="pago"  for="metodo_pago">Método de Pago:</label>
    <select id="metodo_pago" name="metodo_pago">
        <option value="tarjeta">Tarjeta de Crédito</option>
        <option value="paypal">PayPal</option>
    </select>
</form>

<script>
    document.querySelectorAll('button[name="eliminar"]').forEach(button => {
        button.addEventListener('click', function(event) {
            if (!confirm('¿Seguro que deseas eliminar este producto?')) {
                event.preventDefault();
            }
        });
    });

    document.querySelector('button[name="eliminar_todo"]').addEventListener('click', function(event) {
        if (!confirm('¿Seguro que deseas eliminar todos los productos del carrito?')) {
            event.preventDefault();
        }
    });

    document.querySelector('button[name="comprar"]').addEventListener('click', function(event) {
        if (!confirm('¿Seguro que deseas realizar la compra?')) {
            event.preventDefault();
        }
    });
</script>
</body>
</html>



