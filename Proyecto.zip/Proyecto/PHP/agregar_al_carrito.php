<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['user_id'])) {
    // Obtener los datos del producto del cuerpo de la solicitud
    $data = json_decode(file_get_contents("php://input"));

    // Validar y limpiar los datos del producto
    $productId = filter_var($data->productId, FILTER_SANITIZE_NUMBER_INT);
    $price = filter_var($data->price, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

    // Conexión a la base de datos (usando tu base de datos)
    $dsn = "mysql:dbname=VelocidadyEstilo;host=127.0.0.1;";
    $usuario = "root";
    $clave = "";

    try {
        $bd = new PDO($dsn, $usuario, $clave);
        $bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $bd->beginTransaction();
        
        // Verificar el stock del producto
        $stmt = $bd->prepare("SELECT stock FROM Productos WHERE id = :id_producto");
        $stmt->execute(['id_producto' => $productId]);
        $stock = $stmt->fetchColumn();

        if ($stock > 0) {
            // Restar 1 al stock del producto
            $stmt = $bd->prepare("UPDATE Productos SET stock = stock - 1 WHERE id = :id_producto");
            $stmt->execute(['id_producto' => $productId]);

            // Insertar el producto en la tabla del carrito
            $stmt = $bd->prepare("INSERT INTO Cuentas (id_usuario, id_producto, precio) VALUES (:id_usuario, :id_producto, :precio)");
            $stmt->execute([
                'id_usuario' => $_SESSION['user_id'],
                'id_producto' => $productId,
                'precio' => $price
            ]);

            // Confirmar la transacción
            $bd->commit();

            // Si se insertó correctamente, enviar respuesta 200 (OK)
            http_response_code(200);
        } else {
            // Si no hay suficiente stock, enviar respuesta 400 (Bad Request) y mensaje de error
            http_response_code(400);
            echo "No hay suficiente stock disponible para este producto.";
        }
    } catch (PDOException $e) {
        // Si ocurrió un error, revertir la transacción y enviar respuesta 500 (Error del servidor)
        $bd->rollBack();
        http_response_code(500);
        echo "Error: " . $e->getMessage();
    }
} else {
    // Si no se recibió una solicitud POST o el usuario no está autenticado, enviar respuesta 403 (Prohibido)
    http_response_code(403);
}
?>
