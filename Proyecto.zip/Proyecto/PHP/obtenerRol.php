<?php
session_start();
if (isset($_SESSION["usuario_id"])) {
    $usuario_id = $_SESSION["usuario_id"];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "VelocidadyEstilo";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    $sql = "SELECT role FROM Usuarios WHERE id = $usuario_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $role = $row["role"];
            if ($role === "admin") {
                $_SESSION["admin"] = true;
            } else {
                $_SESSION["admin"] = false;
            }
        }
    }
    $conn->close();
}
?>
