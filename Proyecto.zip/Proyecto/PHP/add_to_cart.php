<?php
session_start();

if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$precio = $_POST['precio'];
$escuderia = $_POST['escuderia'];
$talla = $_POST['talla'];

$producto = [
    'id' => $id,
    'nombre' => $nombre,
    'precio' => $precio,
    'escuderia' => $escuderia,
    'talla' => $talla,
    'cantidad' => 1
];

// Verificar si el producto ya está en el carrito
$producto_encontrado = false;
foreach ($_SESSION['carrito'] as &$item) {
    if ($item['id'] == $id && $item['talla'] == $talla) {
        $item['cantidad']++;
        $producto_encontrado = true;
        break;
    }
}

if (!$producto_encontrado) {
    $_SESSION['carrito'][] = $producto;
}

echo "Producto añadido al carrito";
?>
