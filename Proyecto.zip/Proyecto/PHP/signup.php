<?php
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $apellidos = $_POST["apellidos"];
    $correo = $_POST["correo"];
    $usuario = $_POST["usuario"];
    $passwd = $_POST["passwd"];
    $direccion = $_POST["direccion"];

    $dsn = "mysql:dbname=VelocidadyEstilo;host=127.0.0.1;";
    $usuarioBD = "root";
    $clave = "";
    try {
        $bd = new PDO($dsn, $usuarioBD, $clave);
        $sql = "INSERT INTO Usuarios (nombre, apellidos, correo, usuario, passw, direccion) VALUES (:nombre, :apellidos, :correo, :usuario, :passw, :direccion)";
        $stmt = $bd->prepare($sql);
        $stmt->execute(['nombre' => $nombre, 'apellidos' => $apellidos, 'correo' => $correo, 'usuario' => $usuario, 'passw' => $passwd, 'direccion' => $direccion]);
        echo json_encode(['success' => true, 'message' => 'Registro exitoso.']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Falló la conexión: ' . $e->getMessage()]);
    }
}
?>
