<?php
session_start();

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "VelocidadyEstilo";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verificar si se envió un formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir datos del formulario
    $nombre = $_POST['nombre'];
    $precio = $_POST['precio'];
    $imagen = $_POST['ruta_imagen'];
    $escuderia = $_POST['escuderia'];
    $talla = $_POST['talla'];
    $cantidad = $_POST['cantidad'];

    // Verificar si el producto ya existe en la base de datos
    $sql = "SELECT * FROM Productos WHERE nombre = ? AND talla = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $nombre, $talla);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // El producto ya existe, actualizar la cantidad
        $row = $result->fetch_assoc();
        $id_producto = $row['id'];
        $cantidad_actual = $row['cantidad'];

        $nueva_cantidad = $cantidad_actual + $cantidad;

        // Actualizar la cantidad del producto existente
        $sql_update = "UPDATE Productos SET cantidad = ? WHERE id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("ii", $nueva_cantidad, $id_producto);
        $stmt_update->execute();

        echo "Cantidad del producto actualizada en la base de datos";
    } else {
        // El producto no existe, insertar un nuevo registro
        $sql_insert = "INSERT INTO Productos (nombre, precio, imagen, talla, escuderia, cantidad) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("sdsssi", $nombre, $precio, $imagen, $talla, $escuderia, $cantidad);
        $stmt_insert->execute();

        echo "Producto insertado en la tabla de productos";
    }

    echo '<script type="text/javascript">
    alert("Producto agregado");
    window.location.href = "/HTML/añadirProducto.html"; // Redirige a la página de inicio de sesión
</script>';
}
?>
