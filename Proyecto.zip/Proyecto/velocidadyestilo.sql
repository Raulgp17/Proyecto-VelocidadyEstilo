-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-06-2024 a las 23:02:43
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `velocidadyestilo`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administradores`
--

CREATE TABLE `administradores` (
  `id` int(10) UNSIGNED NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `passw` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuentas`
--

CREATE TABLE `cuentas` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED DEFAULT NULL,
  `id_producto` int(10) UNSIGNED DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `destino` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `cuentas`
--

INSERT INTO `cuentas` (`id`, `id_usuario`, `id_producto`, `precio`, `destino`) VALUES
(21, 1, 19, 90.00, 'Dirección de envío'),
(22, 1, 23, 60.00, 'Dirección de envío');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `imagen` varchar(100) DEFAULT NULL,
  `talla` varchar(50) DEFAULT NULL,
  `escuderia` varchar(50) DEFAULT NULL,
  `cantidad` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `precio`, `imagen`, `talla`, `escuderia`, `cantidad`) VALUES
(14, 'camiseta', 50.00, 'https://www.cdn-docs-cft.com/docs/img/gross/28167/scuderia-ferrari-team-camiseta.jpg', 'S', 'Ferrari', 10),
(16, 'camiseta Aston', 60.00, 'https://shop.soymotor.com/img/p/2/0/0/8/5/20085-large_default.jpg', 'M', 'Aston Martin', 8),
(17, 'Camiseta Aston', 60.00, 'https://shop.soymotor.com/img/p/2/0/0/8/5/20085-large_default.jpg', 'S', 'Aston Martin', 3),
(19, 'chaqueta BMW', 90.00, 'https://i.ebayimg.com/images/g/TJEAAOSwE3lj142g/s-l1200.jpg', 'M', 'BMW Sauber', 2),
(20, 'camiseta haas', 70.00, 'https://images.footballfanatics.com/haas-f1-team/haas-f1-moneygram-2024-team-t-shirt_ss5_p-201110605', 'S', 'Haas', 2),
(21, 'chaqueta jaguar', 90.00, 'https://i.ebayimg.com/thumbs/images/g/iiEAAOSwTxtl0hM7/s-l640.jpg', 'XL', 'Jaguar', 4),
(23, 'camiseta Stake f1', 60.00, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGVUBM1nV4SB6JGGQYSD1AZljTouDkT_WhOQ&s', 'L', 'Kick Sauber', 2),
(24, 'camiseta Lotus', 80.00, 'https://m.media-amazon.com/images/I/61Uj1gfB7fL._AC_UY580_.jpg', 'L', 'Lotus', 3),
(26, 'camiseta mercedes', 60.00, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaV1O-F9aOIKmyWBcTY291k5__ezjtGuKFWQ&s', 'L', 'Mercedes', 2),
(27, 'camiseta renault', 60.00, 'https://i.ebayimg.com/images/g/eU0AAOSwP9lkkuAd/s-l1600.jpg', 'L', 'Renault', 2),
(28, 'camiseta redbull', 70.00, 'https://shop.soymotor.com/img/p/2/0/0/0/1/20001-large_default.jpg', 'L', 'Red Bull', 3),
(29, 'camiseta mclaren', 60.00, 'https://images.footballfanatics.com/mclaren-f1-team/mclaren-2024-team-set-up-t-shirt-autumn-womens_s', 'L', 'Mclaren', 4),
(30, 'camiseta ferrari', 60.00, 'https://www.merchandisingplaza.es/517406/2/Camisetas-Ferrari-Camiseta-Ferrari--Rojo--l.jpg', 'L', 'Ferrari', 4),
(31, 'camiseta ferrari', 60.00, 'https://www.merchandisingplaza.es/517406/2/Camisetas-Ferrari-Camiseta-Ferrari--Rojo--l.jpg', 'XL', 'Ferrari', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `passw` varchar(40) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellidos`, `correo`, `usuario`, `passw`, `direccion`, `role`) VALUES
(1, 'admin', 'admin', 'asdqw@gmail.com', 'admin', 'admin1234', 'qefwwregvwrbv', 'admin'),
(2, 'Raúl', 'González perera', 'wefgswrgwg@efwfvsvew.com', 'raul', '1234', 'c/ Escuela de Capataces nº12 1º', 'user');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administradores`
--
ALTER TABLE `administradores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- Indices de la tabla `cuentas`
--
ALTER TABLE `cuentas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_producto` (`id_producto`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correo` (`correo`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `administradores`
--
ALTER TABLE `administradores`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cuentas`
--
ALTER TABLE `cuentas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cuentas`
--
ALTER TABLE `cuentas`
  ADD CONSTRAINT `cuentas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `cuentas_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
