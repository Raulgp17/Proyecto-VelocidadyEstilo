document.addEventListener('DOMContentLoaded', () => {
    const nombreUsuario = getCookie('nombre_usuario');
    if (nombreUsuario) {
        const sesionLink = document.getElementById('Sesion');
        sesionLink.style.display = 'none'; // Oculta el icono de inicio de sesión si el usuario ha iniciado sesión

        const nombreUsuarioSpan = document.getElementById('nombreUsuario');
        nombreUsuarioSpan.textContent = `Hola, ${decodeURIComponent(nombreUsuario)}`;
    }
    
    const cerrarSesionBtn = document.getElementById('cerrarSesion');
    if (cerrarSesionBtn) {
        cerrarSesionBtn.addEventListener('click', cerrarSesion);
    }
});

function getCookie(name) {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i].trim();
        if (cookie.startsWith(name + '=')) {
            return cookie.substring(name.length + 1);
        }
    }
    return null;
}

function cerrarSesion() {
    document.cookie = 'nombre_usuario=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    // Redirige a la página de inicio de sesión
    window.location.href = 'paginaPricipal.html';
}





    
