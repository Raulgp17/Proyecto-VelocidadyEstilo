$(document).ready(function() {
    $('#formularioRegistro').on('submit', function(event) {
        event.preventDefault();

        // recoge los datos del formulario en un objeto FormData
        var formData = new FormData(this);

        // Manda la informacion al servidor
        fetch('../php/signup.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            console.log(data);
            if (data.success) {
                window.location.href = '../../HTML/login.html';
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("Error en el servidor. Inténtelo de nuevo más tarde.");
        });
    });
});
