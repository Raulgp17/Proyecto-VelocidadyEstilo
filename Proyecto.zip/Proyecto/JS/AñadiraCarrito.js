document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', () => {
        const productId = button.getAttribute('data-product-id');
        const price = button.getAttribute('data-price');
        
        // Realizar una solicitud AJAX para añadir el producto al carrito
        fetch('agregar_al_carrito.php', { 
            method: 'POST', 
            body: JSON.stringify({ productId, price }),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            if (response.ok) {
                alert('Producto añadido al carrito correctamente');
            } else {
                alert('Error al añadir producto al carrito');
            }
        })
        .catch(error => console.error('Error:', error));
    });
});
