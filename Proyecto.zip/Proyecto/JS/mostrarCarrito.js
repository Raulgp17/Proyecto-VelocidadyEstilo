document.addEventListener('DOMContentLoaded', () => {
    const cartContent = document.getElementById('cart-content');
    const totalPriceEl = document.getElementById('total-price');
    let cart = JSON.parse(localStorage.getItem('cart')) || {};

    let totalPrice = 0;
    for (const [product, details] of Object.entries(cart)) {
        const productEl = document.createElement('div');
        productEl.className = 'cart-item';
        productEl.innerHTML = `
            <p>Producto: ${product}</p>
            <p>Precio unitario: ${details.price}€</p>
            <p>Cantidad: ${details.quantity}</p>
            <p>Precio total: ${details.totalPrice}€</p>
        `;
        cartContent.appendChild(productEl);
        totalPrice += details.totalPrice;
    }

    totalPriceEl.textContent = totalPrice;
});
