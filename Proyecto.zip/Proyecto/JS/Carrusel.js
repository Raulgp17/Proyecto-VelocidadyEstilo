let currentIndex = 0;

function showSlides(index) {
    const slides = document.querySelectorAll('.carousel-slide a');
    const totalSlides = slides.length;
    const visibleSlides = 3; // Tres elementos visibles por fila

    if (index >= Math.ceil(totalSlides / visibleSlides)) {
        currentIndex = 0;
    } else if (index < 0) {
        currentIndex = Math.ceil(totalSlides / visibleSlides) - 1;
    } else {
        currentIndex = index;
    }

    const offset = -currentIndex * 100 / visibleSlides;
    document.querySelector('.carousel-slide').style.transform = `translateX(${offset}%)`;
}

function prevSlide() {
    showSlides(currentIndex - 1);
}

function nextSlide() {
    showSlides(currentIndex + 1);
}

document.addEventListener('DOMContentLoaded', () => {
    showSlides(currentIndex);
});
//Mostrar el apartado de añadoir producto dependiendo de si eres admin o no 
if (isAdmin) {
    document.getElementById("admin-section").style.display = "block"; // Muestra el apartado del administrador
} else {
    document.getElementById("admin-section").style.display = "none"; // Oculta el apartado del administrador
}
//funcionde busqueda